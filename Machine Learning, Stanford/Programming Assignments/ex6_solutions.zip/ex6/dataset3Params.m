function [C, sigma] = dataset3Params(X, y, Xval, yval)

% List of C & sigma values
C_list = [0.03, 0.3, 3, 30];
s_list = [0.01, 0.1, 1, 10];

% create a blank results matrix
results = zeros(length(C_list) * length(s_list), 3);   

row = 1;
for C_val = C_list
    for sigma_val = s_list
        
        model = svmTrain(X, y, C_val, @(x1, x2) gaussianKernel(x1, x2, sigma_val)); 
        predictions = svmPredict(model, Xval);
        err_val = mean(double(predictions ~= yval));
       
        % save the results in the matrix
        results(row,:) = [C_val sigma_val err_val];
        row = row + 1;
    end
end

% use the min() function on the results matrix to find 
%   the C and sigma values that give the lowest validation error

[v i] = min(results(:,3));
 C = results(i,1);
 sigma = results(i,2);


end
