function [J, grad] = linearRegCostFunction(X, y, theta, lambda)
%LINEARREGCOSTFUNCTION Compute cost and gradient for regularized linear 
%regression with multiple variables

% Initialize some useful values
m = length(y); % number of training examples

h = X * theta;
J_u = 1/(2 * m) * sum((h - y).^2); 
theta(1) = 0;
reg = lambda/ (2 * m) * sum(theta.^2);

% Regularized cost fuction
J = J_u + reg; 

grad_u = (1/m) * (X' * (h - y));
reg = (lambda/m) * theta;

% Regularizedgradient
grad = grad_u + reg;

grad = grad(:);

end
