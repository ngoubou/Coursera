function J = computeCost(X, y, theta)
%COMPUTECOST Compute cost for linear regression
%   J = COMPUTECOST(X, y, theta) computes the cost of using theta as the
%   parameter for linear regression to fit the data points in X and y

% Initialize some useful values
m = length(y); % number of training examples
hypothesis = theta(1)*X(:,1) + theta(2)*X(:,2); % hypothesis function 
sqerrors = (hypothesis - y).^2; % squarred errors
% since X has 2 columns instead of 1, we multiply each theta by the
% corresponding column of X. The 1st column of X is set to 1 so we can
% treat theta_0 as a parameter

% You need to return the following variables correctly 
J = 1/(2 * m) * sum(sqerrors);

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost of a particular choice of theta
%               You should set J to the cost.



% =========================================================================

end
