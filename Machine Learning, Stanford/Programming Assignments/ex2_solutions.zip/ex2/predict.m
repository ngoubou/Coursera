function p = predict(theta, X)
%PREDICT Predict whether the label is 0 or 1 using learned logistic 
%regression parameters theta
%   p = PREDICT(theta, X) computes the predictions for X using a 
%   threshold at 0.5 (i.e., if sigmoid(theta'*x) >= 0.5, predict 1)

m = size(X, 1); % Number of training examples

% You need to return the following variables correctly
p = zeros(m, 1);
hypo = sigmoid(X * theta); % hypothesis function
for i = 1:m
    if hypo(i) >= 0.5
        p(i) = 1;
    else
        p(i) = 0;
    end
end

%theta(1) * x(:,1) + theta(2) * x(:,2) + theta(3) * x(:,3)
% ne pas écrire theta'x, mais écrire sous forme addition
% sigmoid(x * theta) = sigmoid(theta(1) * x(:,1) + theta(2) * x(:,2) +
% theta(3) * x(:,3)) =/= sigmoid(theta'*x)


end
