function g = sigmoid(z)
%SIGMOID Compute sigmoid function
%   g = SIGMOID(z) computes the sigmoid of z.

% we 1st initialize an empty matrix that will store our values
%g = zeros(size(z));
g = 1 ./  (1+ exp(-z)); % better version of below code

% store the matrix dimensions in an array, so i can iterate over it
%[r, c] = size(z);
%for i = 1:r % number of rows in matrix
 %   for j = 1:c % number of columns in matrix
  %      g(i,j) = 1 / (1+ exp(-z(i,j)));
   % end
    

end
