function [J, gradient] = testnew(theta, X, y)
m = length(y);
[r1, c1] = size(X);
[r2, c2] = size(theta);
z = zeros(r1, c2);
for i = 1:r2
    z = z + theta(i) * X(:,i); 
end

%z = theta(1)*X(:,1) + theta(2)*X(:,2) + theta(3)*X(:,3) + theta(4)*X(:,4);
h = sigmoid(z); 

J = 1/m * (sum(-y' * log(h)) - sum((1-y)' * log(1-h)));
%J = 1/m .* sum(-y .* log(h) - (1-y) .* log(1-h));
gradient = 1/m * (X' * (h-y));  
end

%X = [ones(3,1) magic(3)];
%y = [1 0 1]';
%theta = [-2 -1 1 2]';
% Compute the unregularized gradients "grad" using the vector product of X and (h - y),
% scaled by 1/m. Since X has size (m x n) and (h-y) has size (m x 1), 
% you'll need to transpose one of them and arrange the order of the operands 
% so that the result is size (n x 1). This is the unregularized gradient. 
% Note that the vector product also includes the required summation - so you don't need the sum() function.