function [J, grad] = costFunction(theta, X, y)
m = length(y); % number of training examples
[r1, c1] = size(X);
[r2, c2] = size(theta);
z = zeros(r1, c2);
for i = 1:r2
    z = z + theta(i) * X(:,i); 
end

h = sigmoid(z); 

J = 1/m * (sum(-y' * log(h)) - sum((1-y)' * log(1-h))); % cost
grad = 1/m * (X' * (h-y)); % gradient

end
