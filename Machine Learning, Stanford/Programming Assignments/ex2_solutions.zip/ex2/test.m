function grad = test(theta, X, y)

m = length(y); % number of training examples
h = sigmoid(theta' .* X); % hypothesis function

J = 1/m * sum(-y .* log(h) - (1-y) .* log(1-h)); % cost
grad = zeros(size(theta)); % gradient
num_iters = 1500;
alpha = 0.01;
J_history = zeros(num_iters, 1);
[r, c] = size(X);
%deriv = zeros(c,1);
temp = zeros(1, c);
% i multiply deriv by -100 cause my results was off by this margin,
% but don't know why (i should not divide gradient by m)
for iter = 1:num_iters
    for j = 1:c       
        deriv = (sum((h - y) .* X(:,j))); % deriv times x(i)
        temp(j) = theta(j) - alpha * deriv(j);
        grad(j) = temp(j);
    end    
    
    theta(1) = temp(1);
    theta(2) = temp(2);
    theta(3) = temp(3);
    h = sigmoid(theta' .* X); % problem comes from either here or theta
    J = 1/m * sum(-y .* log(h) - (1-y) .* log(1-h));    
    J_history(iter) = min(J);
    %grad = theta;
   if iter > 1 && J_history(iter - 1) - J_history(iter - 1) > 10^-3
       break;
   end
         

end

end
