function [J, grad] = costFunctionReg(theta, X, y, lambda)
m = length(y); % number of training examples
[r1, c1] = size(X);
[r2, c2] = size(theta);
z = zeros(r1, c2);
for i = 1:r2
    z = z + theta(i) * X(:,i); 
end

h = sigmoid(z); 

J_u = 1/m * (sum(-y' * log(h)) - sum((1-y)' * log(1-h))); % unreg cost
theta(1) = 0;
J_reg = (lambda / (2 * m)) * (theta' * theta); % regularization term
J = J_u + J_reg; % final cost
grad = 1/m * (X' * (h-y)) + (lambda / m) * theta; % gradient reg

end
