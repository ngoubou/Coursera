function grad = testt(theta, X, y)

m = length(y); % number of training examples
z = theta(1)*X(:,1) + theta(2)*X(:,2) + theta(3)*X(:,3);
h = sigmoid(z);

%J = -1/m * sum(y .* log(h) + (1-y) .* log(1-h)); % cost
grad = zeros(size(theta)); % gradient
num_iters = 1500;
alpha = 0.01;
J_history = zeros(num_iters, 1);
%[r, c] = size(X);


for iter = 1:num_iters
   
        temp1 = theta(1) + alpha * sum(h - y);
        temp2 = theta(2) + alpha * sum((h - y) .* X(:,2));
        temp3 = theta(3) + alpha * sum((h - y) .* X(:,3));
      
        theta(1) = temp1;
        theta(2) = temp2;
        theta(3) = temp3;
        grad(1) = 1/m * sum((h - y) .* X(:,1));
        grad(2) = 1/m * sum((h - y) .* X(:,2));
        grad(3) = 1/m * sum((h - y) .* X(:,3));
        z = theta(1)*X(:,1) + theta(2)*X(:,2) + theta(3)*X(:,3);
        h = sigmoid(z);
        J = -1/m * sum(-y .* log(h) + (1-y) .* log(1-h));
    % Save the cost J in every iteration    
    J_history(iter) = J;
    

    if iter > 1 && J_history(iter - 1) - J_history(iter - 1) > 10^-3
        break;
    end

end

end
