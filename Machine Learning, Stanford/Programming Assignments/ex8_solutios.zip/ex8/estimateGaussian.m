function [mu, sigma2] = estimateGaussian(X)

% Useful variables
[m, ~] = size(X); % replaced the 2nd value of the output (n) by a tilde

% You should return these values correctly
mu = (1/m) * sum(X);
sigma2 = var(X,1);
% equivalent to the above code (1/m) * sum((X - mu).^2);




end
