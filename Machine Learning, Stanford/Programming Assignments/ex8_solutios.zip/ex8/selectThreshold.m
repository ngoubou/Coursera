function [bestEpsilon, bestF1] = selectThreshold(yval, pval)

bestEpsilon = 0;
bestF1 = 0;

stepsize = (max(pval) - min(pval)) / 1000;

for epsilon = min(pval):stepsize:max(pval)

    predictions = (pval < epsilon);    
    tp = sum((predictions == 1) & (yval == 1)); % true positives
    fp = sum((predictions == 1) & (yval == 0)); % false positives
    fn = sum((predictions == 0) & (yval == 1)); % false negatives
    prec = tp / (tp + fp); % precision
    rec = tp / (tp + fn); % recall
    F1 = (2 * prec * rec) / (prec  + rec);
    
    if F1 > bestF1
       bestF1 = F1;
       bestEpsilon = epsilon;
    end
end

end
