
A = rand(5,3);
B = rand(3,5);
C = A * B;
% R = [zeros(5,1), ones(5,1)];
R = [0 1 1 1 0; 1 0 1 0 1; 0 0 1 1 0 ; 1  1 0 1 0; 1 0 1 0 1];

total = 0;
for i = 1:5
    for j = 1:5
        if (R(i,j) == 1)
            total = total + C(i,j);
        end
    end
end

% total = 3.4257

% ligne 1 good
tot1 = sum(sum((A * B) .* R)); % total
% ligne 2 good
c1 = (A * B) .* R; % C
tot2 = sum(c1(:)); % total
% ligne 3 not good
tot3 = sum(sum((A * B) * R)); % total 
% ligne 4 not good
c2 = (A * B) * R; % C
tot4 = sum(c2(:)); % total
