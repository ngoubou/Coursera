function [J_reg, grad] = cofiCostFunc(params, Y, R, num_users, num_movies, ...
                                  num_features, lambda)

% Unfold the U and W matrices from params
X = reshape(params(1:num_movies*num_features), num_movies, num_features);
Theta = reshape(params(num_movies*num_features+1:end), ...
                num_users, num_features);

pred_rating = X * Theta';
   
rating_error = pred_rating - Y;

% (Note: there is a quirk in the submit grader's test case that requires
% you to use the R matrix to ignore movies that have had no ratings).
error_factor = rating_error .* R;

% Used a second sum to get a scalar
J = (1/2) * sum(sum((error_factor).^2));


X_grad = error_factor * Theta;
Theta_grad = error_factor' * X;

X_reg = (lambda/2) * sum(sum((X).^2));
Theta_reg = (lambda/2) * sum(sum((Theta).^2));

J_reg = J + X_reg + Theta_reg;

X_grad_reg = X_grad + (lambda * X);
Theta_grad_reg = Theta_grad + (lambda * Theta);

grad = [X_grad_reg(:); Theta_grad_reg(:)];

end
